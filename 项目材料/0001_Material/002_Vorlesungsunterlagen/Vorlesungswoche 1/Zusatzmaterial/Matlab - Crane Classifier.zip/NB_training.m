% Matlab training file used in the MLA lecture @TUDA 
% FSR 2019 <mla@fsr.tu-darmstadt.de>

clc
clear all
close all

%% settings

w_len = 100;                                                 % set window length;
path_mdl = './Models/CNB_100__.mat';                         % save model to this file

%% load data
data_S = readtable('./Data/Training/output_schwer.csv');     % dataset for heavy load (class 1)
data_L = readtable('./Data/Training/output_leicht.csv');     % dataset for light load (class 0)

data_S = data_S{:,3:5};
data_L = data_L{:,3:5};

%% build statistical features

% build features for the heavy weight
Feat_S = zeros(size(data_S,1)-w_len,12);
row_id = 1;
for ii=0+w_len:size(data_S,1)
   
    values_S = data_S(ii+1-w_len:ii,1:3);       % get last 100 values for acc x, y, z
    win_mean_S = mean(values_S);                % calculate mean for the given window
    win_std_S = std(values_S);                  % calculate standard deviation for the given window
    win_skew_S = skewness(values_S);            % calculate skewness for the given window
    win_kurt_S = kurtosis(values_S);            % calculate kurtosis for the given window
        
    Feat_S(row_id,:) = [win_mean_S win_std_S win_skew_S win_kurt_S];    % save features in Feat_S Matrix
    row_id = row_id+1;
    
end

% build features for the light weight
Feat_L = zeros(size(data_L,1)-w_len,12);
row_id = 1;
for ii=0+w_len:size(data_L,1)
    
    values_L = data_L(ii+1-w_len:ii,1:3);     % get last 100 values for acc x, y, z
    win_mean_L = mean(values_L);
    win_Ltd_L = std(values_L);
    win_skew_L = skewness(values_L);
    win_kurt_L = kurtosis(values_L);
        
    Feat_L(row_id,:) = [win_mean_L win_Ltd_L win_skew_L win_kurt_L];    % save features in Feat_L Matrix
    row_id = row_id+1;
    
end


%% learn data with Naive Bayes Classifier

% init class lables (use ones for heavy weight and zeros for light weight)
Y_heavy = ones(size(Feat_S,1),1);           % heavy weights will be labelled with "1"
Y_light = zeros(size(Feat_L,1),1);          % light weights will be labelled with "0"
Y_Class = [Y_heavy; Y_light];

% build predictor matrix (rows=observations, columns=features)
X_predictor = [Feat_S(:,1:1);Feat_L(:,1:1)];    % NOTE: Here only the first feature (mean x_acc is used)

% run the training process and save the created model
mdl = fitcnb(X_predictor, Y_Class, 'ClassNames',{'1', '0'});
save(path_mdl, 'mdl');