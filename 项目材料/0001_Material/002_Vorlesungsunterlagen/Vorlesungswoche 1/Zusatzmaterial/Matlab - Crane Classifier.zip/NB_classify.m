% Matlab classification file used in the MLA lecture @TUDA 
% FSR 2019 <mla@fsr.tu-darmstadt.de>



% clear workspace and screen
clc
clear all
close all

%% settings

w_len = 100;                        % set window length;
buf_len = 2000;                     % buffer size (2000=20s)
mdl = './Models/CNB_100__.mat';     % trained model

% data settings
data_in = './Data/Validation/output.csv'    % input data


% load data
data = readtable(data_in);          % read data in
data = data{:,3:5};                 % parse table

load(mdl);                          % load model

% set up data buffers 
buf = zeros(buf_len,3);             % store raw sensor data
buf_Y = zeros(buf_len,2);           % store results (class, confidence)
buf_t = (1:buf_len)'./1000;         % store time vector


% prepare visual output (NOTE: These lines are only required to generate
% the visial output
figure
sph1 = subplot(2,1,1);
ph1 = plot(buf_t, buf);
ylim([-0.5 1.5])
title('Sensor data (raw) [g]')
xlabel('t [s]')
ylabel('Acc. [g]')
legend({'Acc x', 'Acc y', 'Acc z'})
sph2 = subplot(2,1,2);
ph2 = plot(buf_t, buf_Y);
ylim([-0.1 1.1])
title('ML Output')
xlabel('t [s]')
ylabel('Class, Pr')
legend({'1=Heavy, 0=Light', 'confidence'})

for kk=1:size(data,1)            % iterate over data
    
    values = data(kk,:);                        % read data and parse string    
    
    if(length(values) == 3)
    
        % build t vector
        t = buf_t(end)+1;                       % next step    
        buf_t(1,:) = [];                        % remove first element
        buf_t(end+1,:) = t;                     % append current time 

        % append data to buffer (ring buffer)
        buf(1,:) = [];                          % remove first elements
        buf_Y(1,:) = [];        
        buf(end+1,:) = values(1:end);           % append sensor data                        
        buf_Y(end+1,:) = buf_Y(end,:);          % append label (hold last)                       
        
        % perform the calculations every 10th iteration (save calculation
        % time)                          
        if(mod(kk,10) == 0)            
                         
            % calculate features (mean_x,y,z and std_x,y,z) from observed
            % data ( we will only use the mean of the x_acc here ), again
            % again a window length of 100 is used. 
            Feat = mean(buf(end-w_len+1:end,1));

            % use classifier model to estimate class of current
            % observations (this is where all the magic happens and our
            % previously trained Naive Bayes Classifier is used to
            % estimated the current weight class based on the feature
            [Y,Posterior,Cost] = predict(mdl, [Feat(:,1)]);             

            buf_Y(end, 1) = str2double(Y{1});          % save label
            if(buf_Y(end, 1) == 1)  
                buf_Y(end, 2) = Posterior(1);          % save probability
            else
                buf_Y(end, 2) = Posterior(2);          % save probability
            end            
                               
            % write feature, class and probability to console
            disp([' m=' num2str(Feat(1)) ' ' Y{1} ' (' num2str(buf_Y(end, 2)) ')'])
            
            % update the plots
            % update plot 1
            ph1(1).XData = buf_t;
            ph1(2).XData = buf_t;
            ph1(3).XData = buf_t;
            ph1(1).YData = buf(:,1);            
            ph1(2).YData = buf(:,2);        
            ph1(3).YData = buf(:,3);        
            xlim(sph1, [min(buf_t) max(buf_t)+5])            
            % update plot 2
            ph2(1).XData = buf_t;
            ph2(2).XData = buf_t;
            ph2(1).YData = buf_Y(:,1);            
            ph2(2).YData = buf_Y(:,2);        
            xlim(sph2, [min(buf_t) max(buf_t)+5])
            drawnow();                 
            
         end
            
    end
    
    
end